# BikeDekhoAutomation

Intermediate-level Selenium + Java + TestNG automation framework for the BikeDekho Electric Vehicles module.

## Automated Scope
- TC01 Login with valid mobile + manual OTP
- TC02 Electric Bikes navigation
- TC03 Select Electric Bike and verify details
- TC04 September Offers
- TC05 Electric Scooters
- TC06 Electric Cycles
- TC07 Invalid OTP
- TC08 Invalid PIN in Offers

## Manual Scope
- TC09 Charging Station → Location → Locate → Maps
- TC10 EV details, price, EMI and UI verification

## Stack
Java 17, Maven, Selenium 4, TestNG, Page Object Model, PageFactory, Apache POI, Extent Reports, Selenium Grid 4.

## Important
BikeDekho is a live site. Locators and UI behavior can change. The page objects therefore use current public EV URLs plus text-based fallbacks where appropriate. Before a college/demo run, verify the current DOM and update selectors if the site changes.

## OTP
Set environment variables:
- `BIKEDEKHO_MOBILE`
- `BIKEDEKHO_NAME`

TC01 requires manual OTP entry. Never store OTPs or personal credentials in the project.

### Windows PowerShell
```powershell
$env:BIKEDEKHO_MOBILE="your-number"
$env:BIKEDEKHO_NAME="your-name"
mvn clean test -DsuiteXmlFile=testng.xml
```

## Local execution
```bash
mvn clean test -DsuiteXmlFile=testng.xml
```

## Selenium Grid
Start Selenium Grid 4 in standalone mode:
```bash
java -jar selenium-server-<version>.jar standalone
```
Then run:
```bash
mvn clean test -DsuiteXmlFile=crossBrowser.xml
```

## Parallel Grid
```bash
mvn clean test -DsuiteXmlFile=parallel.xml
```

## Reports
- TestNG: `test-output/`
- Extent: `reports/ExtentReport.html`
- Failure screenshots: `screenshots/`

## Project Structure
- `base` — WebDriver setup
- `pages` — Page Objects
- `utils` — configuration, Excel, screenshots, reporting
- `tests` — eight automated test cases
- `listeners` — TestNG listener
- `demos` — Selenium concept demonstrations
- `docs` — sprint plan, test cases and viva guide
