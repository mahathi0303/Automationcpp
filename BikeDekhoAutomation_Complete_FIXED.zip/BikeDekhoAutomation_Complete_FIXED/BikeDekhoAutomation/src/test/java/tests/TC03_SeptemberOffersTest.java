package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseClass;
import utils.ExcelUtils;

public class TC03_SeptemberOffersTest extends BaseClass {

    // ==========================================
    // LOAD EXCEL
    // ==========================================

    @BeforeClass
    public void loadTestData() throws Exception {

        String filePath = "src/test/resources/TestData.xlsx";

        ExcelUtils.loadExcel(filePath, "SeptemberOffers");
    }

    // ==========================================
    // DATA PROVIDER
    // ==========================================

    @DataProvider(name = "SeptemberOffersData")
    public Object[][] getExcelData() {

        int rows = ExcelUtils.getRowCount();

        Object[][] data = new Object[rows - 1][3];

        for (int i = 1; i < rows; i++) {

            data[i - 1][0] = ExcelUtils.getCellData(i, 0);
            data[i - 1][1] = ExcelUtils.getCellData(i, 1);
            data[i - 1][2] = ExcelUtils.getCellData(i, 2);
        }

        return data;
    }

    // ==========================================
    // TEST CASE
    // ==========================================

    @Test(dataProvider = "SeptemberOffersData")
    public void verifySeptemberOffersFlow(
            String pinCode,
            String name,
            String mobileNumber) throws InterruptedException {

        System.out.println("====================================");
        System.out.println("Test Data");
        System.out.println("PIN    : " + pinCode);
        System.out.println("Name   : " + name);
        System.out.println("Mobile : " + mobileNumber);
        System.out.println("====================================");

        // ==========================================
        // OPEN CHROME
        // ==========================================

        // Browser launch, maximize and wait setup
        // are handled by BaseClass

        try {

            // ==========================================
            // OPEN BIKEDEKHO
            // ==========================================

            driver.get("https://www.bikedekho.com/");
            driver.manage().window().maximize();

            // ==========================================
            // ELECTRIC TWO WHEELERS
            // ==========================================

            WebElement electricTwoWheelers = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath(
                                "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]"
                            )
                    )
            );

            Actions actions = new Actions(driver);
            actions.moveToElement(electricTwoWheelers).perform();

            // ==========================================
            // ELECTRIC BIKES
            // ==========================================

            WebElement electricBikes = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul/li[1]/a"
                            )
                    )
            );

            electricBikes.click();

            wait.until(ExpectedConditions.urlContains("electric"));

            // ==========================================
            // SELECT FIRST BIKE
            // ==========================================

            WebElement firstBike = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                "//*[@id='rf01']/div[1]/div[2]/main/div[1]/div[1]/section/ul/li[1]/div/div[1]/img"
                            )
                    )
            );

            firstBike.click();

            wait.until(
                    ExpectedConditions.or(
                            ExpectedConditions.urlContains("bike"),
                            ExpectedConditions.urlContains("electric")
                    )
            );

            // ==========================================
            // SEPTEMBER OFFERS
            // ==========================================

            WebElement septemberOffers = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                "//*[@id='rf01']/div[1]/article/main/div[1]/div[2]/section/div/div[4]/div/div/span"
                            )
                    )
            );

            septemberOffers.click();

            // ==========================================
            // ENTER PIN
            // ==========================================

            WebElement pinInput = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//*[@id='popupcityNameMid']")
                    )
            );

            pinInput.clear();
            pinInput.sendKeys(pinCode);

            Thread.sleep(1500);

            pinInput.sendKeys(Keys.ARROW_DOWN);
            pinInput.sendKeys(Keys.ENTER);

            Thread.sleep(1000);

            // ==========================================
            // CONTINUE
            // ==========================================

            WebElement continueButton = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                "//*[@id='popup']/div/div/div[2]/div[2]/div[3]/button"
                            )
                    )
            );

            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block:'center'});",
                    continueButton
            );

            continueButton.click();

            // ==========================================
            // ENTER NAME
            // ==========================================

            WebElement nameInput = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//*[@id='name']/input")
                    )
            );

            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block:'center'});",
                    nameInput
            );

            Thread.sleep(500);

            nameInput.click();
            nameInput.sendKeys(Keys.CONTROL + "a");
            nameInput.sendKeys(name);

            Assert.assertEquals(
                    nameInput.getAttribute("value"),
                    name,
                    "Name was not entered correctly"
            );

            System.out.println(
                    "Name entered successfully: " + name
            );

            // ==========================================
            // ENTER MOBILE
            // ==========================================

            WebElement mobileInput = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//*[@id='cde']/input")
                    )
            );

            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block:'center'});",
                    mobileInput
            );

            Thread.sleep(500);

            mobileInput.click();
            mobileInput.sendKeys(Keys.CONTROL + "a");
            mobileInput.sendKeys(mobileNumber);

            Assert.assertEquals(
                    mobileInput.getAttribute("value"),
                    mobileNumber,
                    "Mobile number was not entered correctly"
            );

            System.out.println(
                    "Mobile number entered successfully: "
                    + mobileNumber
            );

            // ==========================================
            // PASS
            // ==========================================

            System.out.println("====================================");
            System.out.println("TC03 - September Offers");
            System.out.println("Status : PASSED");
            System.out.println("====================================");

        } finally {

            // Browser closing is handled by BaseClass
        }
    }
}