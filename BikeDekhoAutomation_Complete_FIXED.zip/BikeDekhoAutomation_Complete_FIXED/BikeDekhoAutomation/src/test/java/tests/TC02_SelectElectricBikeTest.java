package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseClass;
import utils.ExcelUtils;

public class TC02_SelectElectricBikeTest extends BaseClass {

    // -------------------------------------------------
    // 1. Load Excel data
    // -------------------------------------------------

    @BeforeClass
    public void setUp() throws Exception {

        String filePath =
                "src/test/resources/TestData_BikeSelection.xlsx";

        ExcelUtils.loadExcel(filePath, "BikeSelection");
    }

    // -------------------------------------------------
    // 2. Read bike names from Excel
    // -------------------------------------------------

    @DataProvider(name = "BikeData")

    public Object[][] getBikeData() {

        int rows = ExcelUtils.getRowCount();

        Object[][] data = new Object[rows - 1][1];

        for (int i = 1; i < rows; i++) {

            data[i - 1][0] =
                    ExcelUtils.getCellData(i, 1);
        }

        return data;
    }

    // -------------------------------------------------
    // 3. Test Case
    // -------------------------------------------------

    @Test(dataProvider = "BikeData")
    public void selectElectricBikeAndOpenDetails(
            String bikeName) {

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "TC02 - Select Electric Bike"
        );

        System.out.println(
                "Bike from Excel: " + bikeName
        );

        System.out.println(
                "=========================================="
        );

        // -------------------------------------------------
        // 4. Open BikeDekho
        // -------------------------------------------------

        driver.get("https://www.bikedekho.com/");

        System.out.println(
                "BikeDekho website opened successfully."
        );

        // -------------------------------------------------
        // 5. Locate Electric Two Wheelers
        // -------------------------------------------------

        By electricTwoWheelersLocator = By.xpath(
                "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]"
        );

        WebElement electricTwoWheelers =
                wait.until(
                        ExpectedConditions.visibilityOfElementLocated(
                                electricTwoWheelersLocator
                        )
                );

        // -------------------------------------------------
        // 6. Hover over Electric Two Wheelers
        // -------------------------------------------------

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block:'center'});",
                electricTwoWheelers
        );

        Actions actions = new Actions(driver);

        actions.moveToElement(
                electricTwoWheelers
        ).perform();

        System.out.println(
                "Mouse moved to Electric Two Wheelers."
        );

        // -------------------------------------------------
        // 7. Locate Electric Bikes
        // -------------------------------------------------

        By electricBikesLocator = By.xpath(
                "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul/li[1]/a"
        );

        WebElement electricBikes =
                wait.until(
                        ExpectedConditions.elementToBeClickable(
                                electricBikesLocator
                        )
                );

        System.out.println(
                "Electric Bikes option appeared."
        );

        // -------------------------------------------------
        // 8. Click Electric Bikes
        // -------------------------------------------------

        electricBikes.click();

        System.out.println(
                "Electric Bikes clicked successfully."
        );

        // -------------------------------------------------
        // 9. Wait for Electric Bikes page
        // -------------------------------------------------

        wait.until(
                ExpectedConditions.urlContains("electric")
        );

        System.out.println(
                "Electric Bikes page opened."
        );

        // -------------------------------------------------
        // 10. Find bike from Excel
        // -------------------------------------------------

        By bikeLocator = By.xpath(
                "//*[contains(normalize-space(),'"
                + bikeName
                + "')]"
        );

        WebElement selectedBike =
                wait.until(
                        ExpectedConditions.visibilityOfElementLocated(
                                bikeLocator
                        )
                );

        // -------------------------------------------------
        // 11. Scroll to selected bike
        // -------------------------------------------------

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block:'center'});",
                selectedBike
        );

        System.out.println(
                "Bike found: " + bikeName
        );

        // -------------------------------------------------
        // 12. Click selected bike
        // -------------------------------------------------

        try {

            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            bikeLocator
                    )
            ).click();

        } catch (Exception e) {

            System.out.println(
                    "Normal click failed. "
                    + "Trying JavaScript click..."
            );

            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].click();",
                    selectedBike
            );
        }

        System.out.println(
                bikeName + " clicked successfully."
        );

        // -------------------------------------------------
        // 13. Wait for bike details page
        // -------------------------------------------------

        wait.until(
                ExpectedConditions.or(
                        ExpectedConditions.urlContains("bike"),
                        ExpectedConditions.urlContains("electric")
                )
        );

        System.out.println(
                "Bike details page opened."
        );

        // -------------------------------------------------
        // 14. Verify details page
        // -------------------------------------------------

        WebElement body =
                wait.until(
                        ExpectedConditions.visibilityOfElementLocated(
                                By.tagName("body")
                        )
                );

        String pageText = body.getText();

        Assert.assertTrue(
                pageText.length() > 100,
                "Bike details page did not load correctly."
        );

        System.out.println(
                "Bike details page verified successfully."
        );

        // -------------------------------------------------
        // 15. Print current URL
        // -------------------------------------------------

        System.out.println(
                "Current URL: " + driver.getCurrentUrl()
        );

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "TC02 PASSED"
        );

        System.out.println(
                "Selected Bike: " + bikeName
        );

        System.out.println(
                "=========================================="
        );
    }

    // Browser setup and browser closing are handled by BaseClass
}