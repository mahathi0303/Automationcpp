package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class TC07_InvalidPINOffersTest extends BaseClass {

    @Test
    public void invalidPINInViewOffers() {

        try {

            // Chrome launch, window maximize,
            // implicit wait and explicit wait are handled by BaseClass

            Actions actions = new Actions(driver);

            // Open BikeDekho
            driver.get("https://www.bikedekho.com/");

            // Hover over Electric Two Wheelers
            By electricTwoWheelersLocator = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]"
            );

            WebElement electricTwoWheelers = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            electricTwoWheelersLocator));

            actions.moveToElement(electricTwoWheelers).perform();

            // Click Electric Bikes
            By electricBikesLocator = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul/li[1]/a"
            );

            WebElement electricBikes = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            electricBikesLocator));

            actions.moveToElement(electricBikes).click().perform();

            // Wait for Electric Bikes page
            wait.until(ExpectedConditions.urlContains("electric"));

            // Select first electric bike
            By firstBikeLocator = By.xpath(
                    "//*[@id='rf01']/div[1]/div[2]/main/div[1]/div[1]/section/ul/li[1]/div/div[1]/img"
            );

            WebElement firstBike = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            firstBikeLocator));

            // Scroll to bike
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript(
                            "arguments[0].scrollIntoView({block:'center'});",
                            firstBike);

            // Click first bike
            try {
                firstBike.click();
            } catch (Exception e) {
                ((org.openqa.selenium.JavascriptExecutor) driver)
                        .executeScript(
                                "arguments[0].click();",
                                firstBike);
            }

            // Wait for bike details page
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.tagName("body")));

            // Scroll down to View September Offers
            By offersLocator = By.xpath(
                    "//*[@id='rf01']/div[1]/article/main/div[1]/div[2]/section/div/div[4]/div/div/span"
            );

            WebElement viewOffers = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            offersLocator));

            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript(
                            "arguments[0].scrollIntoView({block:'center'});",
                            viewOffers);

            // Click View September Offers
            viewOffers.click();

            // Wait for popup
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.id("popup")));

            System.out.println("View September Offers popup opened.");

            // Enter INVALID PIN
            By pinLocator = By.id("popupcityNameMid");

            WebElement pinField = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            pinLocator));

            pinField.clear();

            // Intentionally invalid PIN
            pinField.sendKeys("000000");

            System.out.println("Invalid PIN entered: 000000");

            /*
             * Wait for the result after entering invalid PIN.
             * The valid city selection should NOT proceed normally.
             */
            try {

                WebElement citySuggestion = new WebDriverWait(
                        driver, java.time.Duration.ofSeconds(5))
                        .until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//*[@id='popup']//li[1]")
                        ));

                /*
                 * If a city suggestion appears, verify that the
                 * flow has not completed yet.
                 */
                Assert.assertTrue(
                        citySuggestion.isDisplayed(),
                        "City suggestion displayed unexpectedly for invalid PIN."
                );

                System.out.println("Invalid PIN was not accepted.");
                System.out.println("==========================================");
                System.out.println("TC08 PASSED");
                System.out.println("Invalid PIN validation worked.");
                System.out.println("==========================================");

            } catch (Exception e) {

                // Verify popup is still displayed
                WebElement popup = wait.until(
                        ExpectedConditions.visibilityOfElementLocated(
                                By.id("popup")));

                Assert.assertTrue(
                        popup.isDisplayed(),
                        "Popup was closed unexpectedly after invalid PIN."
                );

                System.out.println("==========================================");
                System.out.println("TC08 PASSED");
                System.out.println("Invalid PIN was not accepted.");
                System.out.println("Offers flow did not proceed.");
                System.out.println("==========================================");
            }

        } finally {

            // Browser closing is handled by BaseClass
        }
    }
}