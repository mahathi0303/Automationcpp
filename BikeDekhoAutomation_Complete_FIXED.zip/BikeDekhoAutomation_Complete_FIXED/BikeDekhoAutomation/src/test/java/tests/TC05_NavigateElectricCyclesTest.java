package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class TC05_NavigateElectricCyclesTest extends BaseClass {

    @Test
    public void navigateToElectricCycles() {

        try {

            // Chrome launch, window maximize,
            // implicit wait and explicit wait are handled by BaseClass

            // Actions class
            Actions actions = new Actions(driver);

            // Open BikeDekho
            driver.get("https://www.bikedekho.com/");

            // Locate Electric Two Wheelers menu
            By electricTwoWheelersLocator = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]"
            );

            WebElement electricTwoWheelers = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            electricTwoWheelersLocator));

            // Hover over Electric Two Wheelers
            actions.moveToElement(electricTwoWheelers).perform();

            // Locate Electric Cycles
            By electricCyclesLocator = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul//a[normalize-space()='Electric Cycles']"
            );

            WebElement electricCycles = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            electricCyclesLocator));

            // Click Electric Cycles
            actions.moveToElement(electricCycles).click().perform();

            // Wait for page navigation
            wait.until(ExpectedConditions.urlContains("electric"));

            // Verify page content
            WebElement body = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.tagName("body")));

            String pageText = body.getText();

            Assert.assertTrue(
                    pageText.toLowerCase().contains("electric"),
                    "Electric Cycles page was not displayed."
            );

            // Print result
            System.out.println("Current URL: " + driver.getCurrentUrl());
            System.out.println("==========================================");
            System.out.println("TC06 PASSED");
            System.out.println("Successfully navigated to Electric Cycles.");
            System.out.println("==========================================");

        } finally {

            // Browser closing is handled by BaseClass
        }
    }
}