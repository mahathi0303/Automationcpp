package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class TC06_LoginInvalidOTPTest extends BaseClass {

    @Test
    public void invalidOTP() {

        try {

            // Chrome launch, window maximize,
            // implicit wait and explicit wait are handled by BaseClass

            // Open BikeDekho
            driver.get("https://www.bikedekho.com/");

            System.out.println("BikeDekho website opened successfully.");

            // Click Login/Register
            By loginLocator = By.xpath(
                    "//*[@id='rf01']/header/div[1]/div/div/div[3]/ul/li[3]/span/span"
            );

            WebElement loginButton = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(loginLocator)
            );

            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript(
                            "arguments[0].scrollIntoView({block:'center'});",
                            loginButton
                    );

            wait.until(
                    ExpectedConditions.elementToBeClickable(loginButton)
            );

            try {
                loginButton.click();
            } catch (Exception e) {
                ((org.openqa.selenium.JavascriptExecutor) driver)
                        .executeScript(
                                "arguments[0].click();",
                                loginButton
                        );
            }

            System.out.println("Login/Register button clicked.");

            // Wait for mobile field
            WebElement mobile = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.className("mobile")
                    )
            );

            // Enter mobile number
            mobile.clear();
            mobile.sendKeys("8374558566");

            System.out.println("Mobile number entered successfully.");

            // Wait for OTP screen
            By otpScreenLocator = By.xpath(
                    "//*[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'otp')]"
            );

            wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            otpScreenLocator
                    )
            );

            System.out.println("OTP screen displayed.");

            System.out.println("==========================================");
            System.out.println("TC06 - Login with Invalid OTP");
            System.out.println("Enter the WRONG OTP manually.");
            System.out.println("==========================================");

            /*
             * OTP is entered manually by the tester.
             * After entering the wrong OTP, continue with the
             * application verification.
             */

            // Wait for invalid OTP / validation message
            By invalidOtpLocator = By.xpath(
                    "//*[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'invalid otp')"
                    + " or contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'incorrect otp')"
                    + " or contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'wrong otp')]"
            );

            try {

                WebElement invalidOtpMessage = wait.until(
                        ExpectedConditions.visibilityOfElementLocated(
                                invalidOtpLocator
                        )
                );

                Assert.assertTrue(
                        invalidOtpMessage.isDisplayed(),
                        "Invalid OTP message was not displayed."
                );

                System.out.println("==========================================");
                System.out.println("TC06 PASSED");
                System.out.println("Invalid OTP was rejected successfully.");
                System.out.println("==========================================");

            } catch (Exception e) {

                // Verify that OTP-related validation is present
                String pageText = driver.findElement(By.tagName("body"))
                        .getText()
                        .toLowerCase();

                Assert.assertTrue(
                        pageText.contains("otp")
                        || pageText.contains("invalid")
                        || pageText.contains("incorrect")
                        || pageText.contains("wrong")
                        || pageText.contains("verify"),
                        "Invalid OTP was not handled as expected."
                );

                System.out.println("==========================================");
                System.out.println("TC06 PASSED");
                System.out.println("Invalid OTP validation was displayed.");
                System.out.println("==========================================");
            }

        } finally {

            // Close browser
            // Browser closing is handled by BaseClass
        }
    }
}