package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class TC04_NavigateElectricScootersTest extends BaseClass {

    @Test
    public void navigateToElectricScooters() {

        try {

            // ==========================================
            // 1. Launch Chrome
            // ==========================================
            // Browser launch, window maximize and wait setup
            // are handled by BaseClass

            Actions actions = new Actions(driver);

            // ==========================================
            // 2. Open BikeDekho
            // ==========================================
            driver.get("https://www.bikedekho.com/");

            // ==========================================
            // 3. Hover over Electric Two Wheelers
            // ==========================================
            By electricTwoWheelersLocator = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]"
            );

            WebElement electricTwoWheelers = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            electricTwoWheelersLocator
                    )
            );

            actions.moveToElement(electricTwoWheelers).perform();

            System.out.println(
                    "Hovered over Electric Two Wheelers."
            );

            // ==========================================
            // 4. Locate Electric Scooters
            // ==========================================
            By electricScootersLocator = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul/li[2]/a"
            );

            WebElement electricScooters = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            electricScootersLocator
                    )
            );

            // ==========================================
            // 5. Click Electric Scooters
            // ==========================================
            actions.moveToElement(electricScooters).click().perform();

            System.out.println(
                    "Electric Scooters clicked successfully."
            );

            // ==========================================
            // 6. Wait for Electric Scooters page
            // ==========================================
            wait.until(
                    ExpectedConditions.urlContains("electric")
            );

            // ==========================================
            // 7. Verify page
            // ==========================================
            WebElement body = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.tagName("body")
                    )
            );

            String pageText = body.getText();

            Assert.assertTrue(
                    pageText.toLowerCase().contains("electric"),
                    "Electric Scooters page was not displayed."
            );

            System.out.println(
                    "Current URL: " + driver.getCurrentUrl()
            );

            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "TC05 PASSED"
            );

            System.out.println(
                    "Successfully navigated to Electric Scooters."
            );

            System.out.println(
                    "=========================================="
            );

        } finally {

            // ==========================================
            // 8. Close Browser
            // ==========================================
            // Browser closing is handled by BaseClass
        }
    }
}