package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class TC01_NavigateElectricBikesTest extends BaseClass {

    @Test
    public void navigateToElectricBikes() {

        // Open BikeDekho

        driver.get("https://www.bikedekho.com/");

        System.out.println(
                "BikeDekho opened successfully"
        );

        // Electric Two Wheelers

        By electricTwoWheelersLocator = By.xpath(
                "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]"
        );

        WebElement electricTwoWheelers = wait.until(

                ExpectedConditions.visibilityOfElementLocated(

                        electricTwoWheelersLocator

                )

        );

        // Hover over Electric Two Wheelers

        Actions actions = new Actions(driver);

        actions.moveToElement(

                electricTwoWheelers

        ).perform();

        System.out.println(

                "Hovered over Electric Two Wheelers"

        );

        // Electric Bikes

        By electricBikesLocator = By.xpath(

                "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul/li[1]/a"

        );

        WebElement electricBikes = wait.until(

                ExpectedConditions.elementToBeClickable(

                        electricBikesLocator

                )

        );

        // Click Electric Bikes

        electricBikes.click();

        System.out.println(

                "Electric Bikes clicked successfully"

        );

        // Wait for Electric Bikes page

        wait.until(

                ExpectedConditions.urlContains("electric")

        );

        // Verify page

        WebElement body = wait.until(

                ExpectedConditions.visibilityOfElementLocated(

                        By.tagName("body")

                )

        );

        String pageText = body.getText();

        Assert.assertTrue(

                pageText.toLowerCase().contains("electric"),

                "Electric Bikes page was not displayed."

        );

        System.out.println(

                "Current URL: " + driver.getCurrentUrl()

        );

        System.out.println(

                "TC01 PASSED: Successfully navigated to Electric Bikes."

        );

    }

}