package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC08_FilterElectricCycleTest {

    WebDriver driver;
    WebDriverWait wait;

    @Test
    public void filterElectricCycles() {

        try {

            // =====================================================
            // 1. LAUNCH CHROME
            // =====================================================

            ChromeOptions options = new ChromeOptions();
            options.addArguments("--disable-notifications");

            driver = new ChromeDriver(options);

            driver.manage().window().maximize();

            // Implicit Wait
            driver.manage().timeouts()
                    .implicitlyWait(Duration.ofSeconds(5));

            // Explicit Wait
            wait = new WebDriverWait(driver, Duration.ofSeconds(30));


            // =====================================================
            // 2. OPEN BIKEDEKHO
            // =====================================================

            driver.get("https://www.bikedekho.com/");

            wait.until(ExpectedConditions
                    .visibilityOfElementLocated(By.tagName("body")));

            System.out.println("BikeDekho opened successfully");


            // =====================================================
            // 3. OPEN ELECTRIC TWO WHEELERS MENU
            // =====================================================

            By electricMenu = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/span/span"
            );

            hoverOnElement(electricMenu);

            System.out.println(
                    "Electric Two Wheelers menu opened successfully");


            // =====================================================
            // 4. CLICK ELECTRIC CYCLES
            // =====================================================

            By electricCycles = By.xpath(
                    "//*[@id='rf01']/header/div[2]/div/div/nav/ul/li[3]/ul/li[3]/a"
            );

            clickElement(electricCycles);


            // =====================================================
            // 5. WAIT FOR ELECTRIC CYCLES PAGE
            // =====================================================

            wait.until(ExpectedConditions.urlContains(
                    "find-electric-cycles"));

            System.out.println(
                    "Electric Cycles page opened successfully");


            // =====================================================
            // FILTER 1 - BRAND
            // =====================================================

            By brandHeading = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[1]/h3"
            );

            clickElement(brandHeading);

            By heroLectro = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[1]/div/ul/li[1]/label"
            );

            selectFilter(
                    heroLectro,
                    "Hero Lectro");


            // =====================================================
            // FILTER 2 - BUDGET
            // =====================================================

            By budgetHeading = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[2]/h3"
            );

            clickElement(budgetHeading);

            By budgetOption = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[2]/div/ul/li[2]/label"
            );

            selectFilter(
                    budgetOption,
                    "Rs. 50,000 - 70,000");


            // =====================================================
            // FILTER 3 - FUEL TYPE
            // =====================================================

            By fuelHeading = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[4]/h3"
            );

            clickElement(fuelHeading);

            By electricFuel = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[4]/div/ul/li/label"
            );

            selectFilter(
                    electricFuel,
                    "Electric");


            // =====================================================
            // FILTER 4 - RANGE
            // =====================================================

            By rangeHeading = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[5]/h3"
            );

            clickElement(rangeHeading);

            By under100Km = By.xpath(
                    "//*[@id='rf01']/div[1]/div/main/div/div[2]/div[1]/div[3]/div/div[5]/div/ul/li[1]/label"
            );

            selectFilter(
                    under100Km,
                    "Under 100 km");


            // =====================================================
            // FILTER 5 - CHARGING TIME
            // =====================================================

            By chargingHeading = By.xpath(
                    "//h3[contains(normalize-space(),'E Bikes Charging Time')]"
            );

            clickElement(chargingHeading);

            By under6Hours = By.xpath(
                    "//label[contains(normalize-space(.),'Under 6 hours')]"
            );

            selectFilter(
                    under6Hours,
                    "Under 6 hours");


            // =====================================================
            // ALL FILTERS SELECTED
            // =====================================================

            System.out.println();
            System.out.println("======================================");
            System.out.println("ALL 5 FILTERS SELECTED");
            System.out.println("======================================");


            // =====================================================
            // 6. WAIT FOR PAGE UPDATE
            // =====================================================

            wait.until(driver ->
                    ((JavascriptExecutor) driver)
                            .executeScript(
                                    "return document.readyState")
                            .equals("complete"));


            // =====================================================
            // 7. SCROLL DOWN TO SHOW CYCLES
            // =====================================================

            ((JavascriptExecutor) driver).executeScript(
                    "window.scrollTo(0, document.body.scrollHeight);"
            );

            System.out.println(
                    "Scrolled down to filtered cycle results");


            // =====================================================
            // 8. WAIT FOR SCROLL TO COMPLETE
            // =====================================================

            wait.until(driver -> {

                Number currentPosition =
                        (Number) ((JavascriptExecutor) driver)
                                .executeScript(
                                        "return window.pageYOffset;");

                Number pageHeight =
                        (Number) ((JavascriptExecutor) driver)
                                .executeScript(
                                        "return document.body.scrollHeight;");

                Number screenHeight =
                        (Number) ((JavascriptExecutor) driver)
                                .executeScript(
                                        "return window.innerHeight;");

                double current =
                        currentPosition.doubleValue();

                double page =
                        pageHeight.doubleValue();

                double screen =
                        screenHeight.doubleValue();

                return current + screen >= page - 150;
            });


            // =====================================================
            // 9. VERIFY CYCLES ARE DISPLAYED
            // =====================================================

            System.out.println();
            System.out.println("======================================");
            System.out.println("FILTERED ELECTRIC CYCLES ARE DISPLAYED");
            System.out.println("======================================");


            String pageText = driver
                    .findElement(By.tagName("body"))
                    .getText();


            boolean cyclesDisplayed =
                    pageText.contains("Hero Lectro")
                    || pageText.contains("Electric")
                    || pageText.contains("Cycles");


            Assert.assertTrue(
                    cyclesDisplayed,
                    "Filtered electric cycles are not displayed."
            );


            System.out.println();
            System.out.println("======================================");
            System.out.println("TC08 PASSED");
            System.out.println("======================================");


        } catch (Exception e) {

            System.out.println();
            System.out.println("======================================");
            System.out.println("TC08 FAILED");
            System.out.println("======================================");

            e.printStackTrace();

            Assert.fail(
                    "Electric Cycle filter test failed: "
                    + e.getMessage());

        } finally {

            // =====================================================
            // 10. CLOSE BROWSER
            // =====================================================

            if (driver != null) {

                driver.quit();

                System.out.println("Browser closed");
            }
        }
    }


    // =========================================================
    // HOVER METHOD
    // Handles StaleElementReferenceException
    // =========================================================

    private void hoverOnElement(By locator) {

        for (int attempt = 1; attempt <= 3; attempt++) {

            try {

                // Find the element fresh every attempt
                WebElement element = wait.until(
                        ExpectedConditions
                                .visibilityOfElementLocated(locator));

                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].scrollIntoView({block:'center'});",
                        element);

                // Find the element AGAIN after scrolling
                element = wait.until(
                        ExpectedConditions
                                .visibilityOfElementLocated(locator));

                new Actions(driver)
                        .moveToElement(element)
                        .perform();

                return;

            } catch (StaleElementReferenceException e) {

                System.out.println(
                        "Menu became stale. Retrying hover... Attempt "
                        + attempt);

            }
        }

        throw new RuntimeException(
                "Unable to hover over Electric Two Wheelers menu.");
    }


    // =========================================================
    // CLICK METHOD
    // Handles StaleElementReferenceException
    // =========================================================

    private void clickElement(By locator) {

        for (int attempt = 1; attempt <= 3; attempt++) {

            try {

                WebElement element = wait.until(
                        ExpectedConditions
                                .visibilityOfElementLocated(locator));

                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].scrollIntoView({block:'center'});",
                        element);

                // Get fresh element after scrolling
                element = wait.until(
                        ExpectedConditions
                                .elementToBeClickable(locator));

                try {

                    element.click();

                } catch (Exception e) {

                    // JavaScript fallback
                    element = wait.until(
                            ExpectedConditions
                                    .visibilityOfElementLocated(locator));

                    ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].click();",
                            element);
                }

                return;

            } catch (StaleElementReferenceException e) {

                System.out.println(
                        "Element became stale. Retrying click... Attempt "
                        + attempt);
            }
        }

        throw new RuntimeException(
                "Unable to click element: " + locator);
    }


    // =========================================================
    // SELECT FILTER METHOD
    // Handles dynamic DOM updates
    // =========================================================

    private void selectFilter(By locator, String filterName) {

        for (int attempt = 1; attempt <= 3; attempt++) {

            try {

                // Always locate a fresh element
                WebElement element = wait.until(
                        ExpectedConditions
                                .visibilityOfElementLocated(locator));

                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].scrollIntoView({block:'center'});",
                        element);


                // Locate element again after scrolling
                element = wait.until(
                        ExpectedConditions
                                .elementToBeClickable(locator));


                try {

                    element.click();

                } catch (Exception e) {

                    // JavaScript click fallback
                    element = wait.until(
                            ExpectedConditions
                                    .visibilityOfElementLocated(locator));

                    ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].click();",
                            element);
                }


                System.out.println(
                        "Selected: " + filterName);

                return;

            } catch (StaleElementReferenceException e) {

                System.out.println(
                        "Filter element became stale. Retrying "
                        + filterName
                        + "... Attempt "
                        + attempt);
            }
        }

        throw new RuntimeException(
                "Unable to select filter: " + filterName);
    }
}