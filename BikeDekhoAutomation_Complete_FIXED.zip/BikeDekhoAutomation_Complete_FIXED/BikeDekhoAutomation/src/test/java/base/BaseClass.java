package base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class BaseClass {

    protected WebDriver driver;

    protected WebDriverWait wait;

    @BeforeMethod
    @Parameters("browser")
    public void setUp(@Optional("chrome") String browser) {

        if (browser.equalsIgnoreCase("chrome")) {

            ChromeOptions options = new ChromeOptions();

            options.addArguments("--disable-notifications");

            driver = new ChromeDriver(options);

        } else if (browser.equalsIgnoreCase("edge")) {

            EdgeOptions options = new EdgeOptions();

            options.addArguments("--disable-notifications");

            driver = new EdgeDriver(options);

        } else {

            throw new IllegalArgumentException(
                "Unsupported browser: " + browser
            );
        }

        driver.manage().window().maximize();

        // Implicit wait
        driver.manage().timeouts()
              .implicitlyWait(Duration.ofSeconds(5));

        // Explicit wait
        wait = new WebDriverWait(
            driver,
            Duration.ofSeconds(30)
        );

        System.out.println(
            "Browser started: " + browser.toUpperCase()
        );
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {

            driver.quit();

            System.out.println("Browser closed");
        }
    }
}