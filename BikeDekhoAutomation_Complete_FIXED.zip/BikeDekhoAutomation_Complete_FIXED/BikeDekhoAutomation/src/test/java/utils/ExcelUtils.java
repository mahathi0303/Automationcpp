package utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtils {

    private static Workbook workbook;
    private static Sheet sheet;

    public static void loadExcel(String filePath, String sheetName)
            throws IOException {

        FileInputStream fis = new FileInputStream(filePath);

        workbook = WorkbookFactory.create(fis);

        sheet = workbook.getSheet(sheetName);

        fis.close();
    }

    public static String getCellData(int row, int column) {

        DataFormatter formatter = new DataFormatter();

        return formatter.formatCellValue(
                sheet.getRow(row).getCell(column)
        );
    }

    public static int getRowCount() {

        return sheet.getPhysicalNumberOfRows();
    }

    public static void closeExcel() throws IOException {

        if (workbook != null) {
            workbook.close();
        }
    }
}